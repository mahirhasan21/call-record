GitHub দিয়ে APK বানানো:
1. github.com এ নতুন repository খুলুন
2. এই জিপের সব ফাইল (ফোল্ডারসহ, .github সহ) আপলোড করুন
3. Actions ট্যাব -> Build APK -> বিল্ড শেষ হলে নিচে Artifacts থেকে CallRecorder-apk নামান
4. জিপ খুলে app-debug.apk ফোনে ইনস্টল করুন
